package teammaze;
/*
 * Team: REPLACE_WITH_TEAM_NAME
 * Contributor: REPLACE_WITH_CONTRIBUTOR_NAME (MazePanel.java)
 *
 * Swing panel that draws the maze and handles keyboard input.
 */
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class MazePanel extends JPanel {
    private final Maze maze;
    private final Player player;
    private final MazeGenerator generator;
    private final int cellSize;

    public MazePanel(Maze maze, Player player, MazeGenerator generator, int cellSize) {
        this.maze = maze;
        this.player = player;
        this.generator = generator;
        this.cellSize = cellSize;

        setPreferredSize(new Dimension(maze.getCols() * cellSize, maze.getRows() * cellSize));
        setBackground(Color.BLACK);
        setFocusable(true);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                int code = e.getKeyCode();
                switch (code) {
                    case KeyEvent.VK_UP:    player.move(-1, 0, maze); break;
                    case KeyEvent.VK_DOWN:  player.move( 1, 0, maze); break;
                    case KeyEvent.VK_LEFT:  player.move( 0,-1, maze); break;
                    case KeyEvent.VK_RIGHT: player.move( 0, 1, maze); break;
                    case KeyEvent.VK_R:
                        generator.generate(maze);
                        player.reset(1,1);
                        break;
                }
                repaint();
            }
        });
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        int[][] grid = maze.getGrid();

        for (int r = 0; r < maze.getRows(); r++) {
            for (int c = 0; c < maze.getCols(); c++) {
                if (grid[r][c] == 1) g.setColor(Color.DARK_GRAY);
                else g.setColor(Color.WHITE);
                g.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
            }
        }

        // Draw start & goal
        g.setColor(Color.GREEN);
        g.fillRect(1 * cellSize, 1 * cellSize, cellSize, cellSize);
        g.setColor(Color.RED);
        g.fillRect((maze.getCols()-2) * cellSize, (maze.getRows()-2) * cellSize, cellSize, cellSize);

        // Draw player
        g.setColor(Color.BLUE);
        g.fillOval(player.getCol() * cellSize + cellSize/4, player.getRow() * cellSize + cellSize/4,
                   cellSize/2, cellSize/2);
    }
}
