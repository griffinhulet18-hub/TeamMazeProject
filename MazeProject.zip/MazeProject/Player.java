package teammaze;
/*
 * Team: REPLACE_WITH_TEAM_NAME
 * Contributor: REPLACE_WITH_CONTRIBUTOR_NAME (Player.java)
 *
 * Tracks player position and validates movement against maze walls.
 */
public class Player {
    private int row;
    private int col;

    public Player(int startRow, int startCol) {
        this.row = startRow;
        this.col = startCol;
    }

    public int getRow() { return row; }
    public int getCol() { return col; }

    public void reset(int r, int c) {
        this.row = r;
        this.col = c;
    }

    public void move(int dr, int dc, Maze maze) {
        int nr = row + dr;
        int nc = col + dc;
        if (maze.inBounds(nr, nc) && maze.isPath(nr, nc)) {
            row = nr;
            col = nc;
        }
    }
}
