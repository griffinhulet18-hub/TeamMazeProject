package teammaze;
/*
 * Team: REPLACE_WITH_TEAM_NAME
 * Contributor: REPLACE_WITH_CONTRIBUTOR_NAME (Maze.java)
 *
 * Maze model backed by an int[][] grid:
 * 1 = wall, 0 = path
 */
public class Maze {
    private final int rows;
    private final int cols;
    private final int[][] grid; // 1 = wall, 0 = path

    public Maze(int rows, int cols) {
        if (rows < 5) rows = 5;
        if (cols < 5) cols = 5;
        // Prefer odd dimensions for nicer mazes
        if (rows % 2 == 0) rows++;
        if (cols % 2 == 0) cols++;
        this.rows = rows;
        this.cols = cols;
        this.grid = new int[rows][cols];
    }

    public int getRows() { return rows; }
    public int getCols() { return cols; }
    public int[][] getGrid() { return grid; }

    public boolean inBounds(int r, int c) {
        return r >= 0 && r < rows && c >= 0 && c < cols;
    }

    public boolean isWall(int r, int c) {
        return grid[r][c] == 1;
    }

    public void setWall(int r, int c, boolean wall) {
        grid[r][c] = wall ? 1 : 0;
    }

    public boolean isPath(int r, int c) {
        return grid[r][c] == 0;
    }
}
