package teammaze;
/*
 * Team: REPLACE_WITH_TEAM_NAME
 * Contributor: REPLACE_WITH_CONTRIBUTOR_NAME (MazeApp.java)
 *
 * Entry point: builds the maze, UI, and starts the game.
 */
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class MazeApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Choose odd dimensions for better mazes
            int rows = 31;
            int cols = 41;
            int cell = 20;

            Maze maze = new Maze(rows, cols);
            MazeGenerator gen = new MazeGenerator();
            gen.generate(maze);

            Player player = new Player(1, 1);
            MazePanel panel = new MazePanel(maze, player, gen, cell);

            JFrame f = new JFrame("Team Maze Game");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setContentPane(panel);
            f.pack();
            f.setLocationRelativeTo(null);
            f.setVisible(true);
            panel.requestFocusInWindow();
        });
    }
}
