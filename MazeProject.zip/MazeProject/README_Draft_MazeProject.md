# Maze Game Project (Draft Version)

### Overview
This is the **draft version** of the Maze Game project for INFO-C211.  
The project demonstrates a simple Java Swing–based maze generator and player navigation system.  
The game generates a random maze using a **DFS backtracking algorithm**, displays it in a window, and allows the player to move with the **arrow keys**.

- **Team Name:** G2
- **Contributors:** Griffin Hulet, Jada Thompson, Maram Algaradi

---

## ⚙️ How to Import and Run in Eclipse

Follow these steps **exactly** to ensure the project compiles and runs properly in Eclipse.

---

### 1. Create the Project

1. Open **Eclipse IDE**.
2. Go to **File → New → Java Project**.
3. Name it exactly:  
   ```
   MazeProject
   ```
4. Click **Finish**.

---

### 2. Create the Package

1. In the **Package Explorer** (left side of Eclipse):
   - Right-click on the **src** folder inside `MazeProject`.
   - Choose **New → Package**.
   - Name it:
     ```
     teammaze
     ```
2. Click **Finish**.

You should now see:  
`MazeProject/src/teammaze/`

---

### 3. Import the Java Files

1. Right-click the new **teammaze** package.
2. Choose **Import → General → File System → Next**.
3. In the “From directory” box, navigate to the folder where you downloaded the `.java` files.
4. Select the following files:
   - `Maze.java`
   - `MazeGenerator.java`
   - `Player.java`
   - `MazePanel.java`
   - `MazeApp.java`
5. Make sure the destination folder on the right says:  
   `MazeProject/src/teammaze`
6. Click **Finish**.

---

### 4. Fix the `SwingUtilities` Compilation Error

If you get an error like:

```
Exception in thread "main" java.lang.Error: Unresolved compilation problem:
SwingUtilities cannot be resolved
```

That means your project was created as a **modular Java project**, which blocks access to Swing.

#### To fix this:
1. In the **Package Explorer**, expand the `MazeProject` node.
2. Find a file named `module-info.java` inside the **src** folder.
3. Right-click it → **Delete** → confirm **OK**.
4. Go to the top menu → **Project → Clean…** → select **MazeProject** → click **OK**.

Now Eclipse will treat the project as a normal Java SE app, and Swing will work correctly.

---

### 5. Verify JRE Settings (if still not running)

If the error persists:
1. Right-click **MazeProject** → **Properties**.
2. Click **Java Build Path** → open the **Libraries** tab.
3. Ensure you see:
   ```
   JRE System Library [JavaSE-17]  or  [JavaSE-21]
   ```
4. If not, click **Add Library… → JRE System Library → Next → Workspace default JRE → Finish → Apply and Close.**

Then go to **Project → Clean… → OK** again and re-run.

---

### 6. Run the Maze

1. In the Package Explorer, open `MazeApp.java`.
2. Click the **green Run ▶** button in the toolbar.

A window should appear showing a randomly generated maze.

---

## 🕹️ Controls

- **Arrow Keys:** Move the blue player circle.  
- **R:** Regenerate a new maze.  
- **Start (Green Square):** Top-left corner.  
- **Goal (Red Square):** Bottom-right corner.

---

## ✅ Requirements Met

- 5 Java classes: `Maze`, `MazeGenerator`, `Player`, `MazePanel`, `MazeApp`
- Uses complex structures (`int[][]` grid, `ArrayList` stack)
- Includes GUI (Swing)
- Includes testing through the main method (`MazeApp`)

---

## 🧩 Next Steps (For Final Version)

- Add win detection (player reaches red goal).  
- Add a move counter or timer.  
- Add resize options or menu buttons.  
- Include 2–3 screenshots in a `/media` folder.  
- Update README with final names and credits.  
- Export Runnable JAR for final submission.

---

### 💡 Tips

If the `Package Explorer` view is not visible:
- Go to **Window → Show View → Package Explorer**.  
This ensures you can expand your project folders and see all `.java` files.

---

### 📁 Folder Structure

```
MazeProject/
  README.md
  media/                (screenshots for final submission)
  src/
    teammaze/
      Maze.java
      MazeGenerator.java
      Player.java
      MazePanel.java
      MazeApp.java
```

---

**This draft version is for testing and team setup.**  
The final version will include code refinements, comments, and documentation updates before submission.
