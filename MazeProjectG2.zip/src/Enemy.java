/*
Team Name: G2
Contributors:
- Maram Algaradi
- Amma Amma Mensah-Dwumfua
- Jada Thompson
- Griffin Hulet

Description: Represents a hazard in the maze.
*/
public class Enemy {
    private int row,col;
    public Enemy(int row,int col){this.row=row;this.col=col;}
    public int getRow(){return row;}
    public int getCol(){return col;}

    public void move(Maze maze){
        int dir=(int)(Math.random()*4);
        int newRow=row,newCol=col;
        switch(dir){
            case 0: newRow=row-1; break;
            case 1: newRow=row+1; break;
            case 2: newCol=col-1; break;
            case 3: newCol=col+1; break;
        }
        if(newRow>0 && newRow<maze.getGrid().length-1 &&
                newCol>0 && newCol<maze.getGrid()[0].length-1 &&
                maze.getGrid()[newRow][newCol]!='#'){
            row=newRow; col=newCol;
        }
    }
}
