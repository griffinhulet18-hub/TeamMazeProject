/*
Team Name: Maze Masters
Contributors:
- Maram Algaradi
- Amma Amma Mensah-Dwumfua
- Jada Thompson
- Griffin Hulet

Description: Generates a maze with guaranteed solvable path, random obstacles
outside the path, supports GUI + console.
*/

import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;

public class Maze {
    private char[][] grid;
    private boolean[][] guaranteedPath;

    public Maze(int rows, int cols, int level){
        grid = new char[rows][cols];
        guaranteedPath = new boolean[rows][cols];

        // Step 1: Initialize all walls
        for(int r=0;r<rows;r++){
            for(int c=0;c<cols;c++){
                grid[r][c]='#';
                guaranteedPath[r][c]=false;
            }
        }

        // Step 2: Carve maze recursively
        carve(1,1, rows, cols);

        // Step 3: Mark guaranteed path from start to target using DFS
        markGuaranteedPath(1,1, rows-2, cols-2);

        // Step 4: Add random obstacles outside guaranteed path
        addObstacles(level);

        // Ensure start and target remain clear
        grid[1][1]='.';
        grid[rows-2][cols-2]='.';
        guaranteedPath[1][1]=true;
        guaranteedPath[rows-2][cols-2]=true;
    }

    private void carve(int r, int c, int rows, int cols){
        grid[r][c]='.'; // carve path
        Integer[] dirs = {0,1,2,3}; // up, down, left, right
        Collections.shuffle(java.util.Arrays.asList(dirs));
        for(int dir : dirs){
            int dr=0, dc=0;
            switch(dir){
                case 0: dr=-2; break; // up
                case 1: dr=2; break;  // down
                case 2: dc=-2; break; // left
                case 3: dc=2; break;  // right
            }
            int newR = r+dr;
            int newC = c+dc;
            if(newR>0 && newR<rows-1 && newC>0 && newC<cols-1 && grid[newR][newC]=='#'){
                grid[r+dr/2][c+dc/2]='.'; // carve intermediate cell
                carve(newR,newC, rows, cols);
            }
        }
    }

    // DFS to mark one guaranteed path from start to target
    private boolean markGuaranteedPath(int r, int c, int targetR, int targetC){
        if(r==targetR && c==targetC){
            guaranteedPath[r][c]=true;
            return true;
        }
        if(grid[r][c]=='#' || guaranteedPath[r][c]) return false;
        guaranteedPath[r][c]=true;

        int[][] moves = {{-1,0},{1,0},{0,-1},{0,1}}; // up, down, left, right
        for(int[] m : moves){
            int newR = r+m[0], newC=c+m[1];
            if(newR>0 && newR<grid.length-1 && newC>0 && newC<grid[0].length-1){
                if(markGuaranteedPath(newR,newC,targetR,targetC)) return true;
            }
        }
        // backtrack if no path
        guaranteedPath[r][c]=false;
        return false;
    }

    private void addObstacles(int level){
        int rows = grid.length;
        int cols = grid[0].length;
        int obstacles = level*5;
        Random rand = new Random();
        for(int i=0;i<obstacles;i++){
            int r,c;
            do{
                r = 1 + rand.nextInt(rows-2);
                c = 1 + rand.nextInt(cols-2);
            } while(grid[r][c]!='.' || guaranteedPath[r][c]);
            grid[r][c]='#';
        }
    }

    public char[][] getGrid(){ return grid; }

    // Console display
    public void printMaze(Player player, Enemy[] enemies, int targetRow, int targetCol){
        for(int r=0;r<grid.length;r++){
            for(int c=0;c<grid[0].length;c++){
                boolean printed=false;
                if(r==player.getRow() && c==player.getCol()){ System.out.print('P'); printed=true; }
                for(Enemy e:enemies){
                    if(r==e.getRow() && c==e.getCol()){ System.out.print('E'); printed=true; break; }
                }
                if(!printed){
                    if(r==targetRow && c==targetCol) System.out.print('T');
                    else System.out.print(grid[r][c]);
                }
            }
            System.out.println();
        }
    }
}
