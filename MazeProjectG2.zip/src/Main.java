/*
Team Name: G2
Contributors:
- Maram Algaradi
- Amma Amma Mensah-Dwumfua
- Jada Thompson
- Griffin Hulet

Description: Entry point to launch the Maze Project GUI or Console version.
*/

public class Main {
    public static void main(String[] args) {

        // Uncomment one of these:

        // Launch GUI version:
        MazeGUI.launchGUI();

        // Launch console version:
        // MazeGame game = new MazeGame();
        // game.start();
    }
}
