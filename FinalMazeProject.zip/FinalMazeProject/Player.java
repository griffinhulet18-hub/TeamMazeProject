package teammaze;
/*
 * Team: Maze Team
 * Contributors: Maram Algaradi, Griffin Hulet, Jada Thompson, Amma Dwum
 *
 * Tracks player position and validates movement against maze walls.
 */
public class Player {
    private int row;
    private int col;

    public Player(int startRow, int startCol) {
        this.row = startRow;
        this.col = startCol;
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public void reset(int r, int c) {
        this.row = r;
        this.col = c;
    }

    // Returns true if the move actually happened (used for move counter)
    public boolean move(int dr, int dc, Maze maze) {
        int nr = row + dr;
        int nc = col + dc;
        if (maze.inBounds(nr, nc) && maze.isPath(nr, nc)) {
            row = nr;
            col = nc;
            return true;
        }
        return false;
    }
}
