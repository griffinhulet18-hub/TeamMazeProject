package teammaze;
/*
 * Team: Maze Team
 * Contributors: Maram Algaradi, Griffin Hulet, Jada Thompson, Amma Dwum
 *
 * Depth-first-search (DFS) backtracker maze generator on a grid of odd dimensions.
 * Treats odd cells as rooms and carves passages by skipping one cell.
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MazeGenerator {
    private final Random rand = new Random();

    public void generate(Maze maze) {
        int rows = maze.getRows();
        int cols = maze.getCols();
        int[][] g = maze.getGrid();

        // Fill everything with walls
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                g[r][c] = 1;
            }
        }

        // Start in the top left "room"
        int startR = 1;
        int startC = 1;
        g[startR][startC] = 0;

        java.util.List<int[]> stack = new java.util.ArrayList<>();
        stack.add(new int[]{startR, startC});

        while (!stack.isEmpty()) {
            int[] cell = stack.get(stack.size() - 1);
            int r = cell[0];
            int c = cell[1];

            List<int[]> neighbors = new ArrayList<>();

            // Potential neighbors two cells away (up, down, left, right)
            int[][] dirs = {{-2, 0}, {2, 0}, {0, -2}, {0, 2}};
            for (int[] d : dirs) {
                int nr = r + d[0];
                int nc = c + d[1];
                if (nr > 0 && nr < rows - 1 && nc > 0 && nc < cols - 1 && g[nr][nc] == 1) {
                    neighbors.add(new int[]{nr, nc});
                }
            }

            if (neighbors.isEmpty()) {
                // backtrack
                stack.remove(stack.size() - 1);
            } else {
                int[] next = neighbors.get(rand.nextInt(neighbors.size()));
                int nr = next[0];
                int nc = next[1];

                // Carve passage between (r,c) and (nr,nc)
                g[(r + nr) / 2][(c + nc) / 2] = 0;
                g[nr][nc] = 0;

                stack.add(new int[]{nr, nc});
            }
        }

        // Ensure start & goal are paths
        g[1][1] = 0;
        g[rows - 2][cols - 2] = 0;
    }
}
