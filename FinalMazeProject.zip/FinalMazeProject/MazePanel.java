package teammaze;
/*
 * Team: Maze Team
 * Contributors: Maram Algaradi, Griffin Hulet, Jada Thompson, Amma Dwum
 *
 * Swing panel that draws the maze, handles keyboard input,
 * tracks moves, and detects when the player reaches the goal.
 */
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class MazePanel extends JPanel {

    private final Maze maze;
    private final Player player;
    private final MazeGenerator generator;

    // Cell size in pixels (can be adjusted for resize feature)
    private int cellSize;

    // Simple move counter
    private int moveCount = 0;

    // Win flag
    private boolean won = false;

    public MazePanel(Maze maze, Player player, MazeGenerator generator, int cellSize) {
        this.maze = maze;
        this.player = player;
        this.generator = generator;
        this.cellSize = cellSize;

        setFocusable(true);
        updatePreferredSize();

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPressed(e);
            }
        });
    }

    private void updatePreferredSize() {
        int width = maze.getCols() * cellSize;
        int height = maze.getRows() * cellSize + 30; // extra space for HUD text
        setPreferredSize(new Dimension(width, height));
        revalidate();
    }

    private void handleKeyPressed(KeyEvent e) {
        int code = e.getKeyCode();

        if (code == KeyEvent.VK_R) {
            regenerateMaze();
            return;
        }

        // Resize options using keyboard
        if (code == KeyEvent.VK_EQUALS || code == KeyEvent.VK_PLUS) {
            changeCellSize(5);
            return;
        } else if (code == KeyEvent.VK_MINUS) {
            changeCellSize(-5);
            return;
        }

        // If already won, ignore movement keys (except R handled above)
        if (won) {
            return;
        }

        int dr = 0;
        int dc = 0;

        switch (code) {
            case KeyEvent.VK_UP:
                dr = -1;
                break;
            case KeyEvent.VK_DOWN:
                dr = 1;
                break;
            case KeyEvent.VK_LEFT:
                dc = -1;
                break;
            case KeyEvent.VK_RIGHT:
                dc = 1;
                break;
            default:
                return; // ignore other keys
        }

        boolean moved = player.move(dr, dc, maze);
        if (moved) {
            moveCount++;
            checkWin();
            repaint();
        }
    }

    // Called by menu items or R key
    public void regenerateMaze() {
        generator.generate(maze);
        player.reset(1, 1);
        moveCount = 0;
        won = false;
        requestFocusInWindow();
        repaint();
    }

    // Called by menu items or +/- keys
    public void changeCellSize(int delta) {
        int newSize = cellSize + delta;
        if (newSize < 10) newSize = 10;
        if (newSize > 60) newSize = 60;
        cellSize = newSize;
        updatePreferredSize();
        repaint();
    }

    private void checkWin() {
        int goalRow = maze.getRows() - 2;
        int goalCol = maze.getCols() - 2;
        if (player.getRow() == goalRow && player.getCol() == goalCol) {
            won = true;
            // Show a simple dialog with move count
            JOptionPane.showMessageDialog(
                    this,
                    "You reached the goal in " + moveCount + " moves!",
                    "Maze Complete",
                    JOptionPane.INFORMATION_MESSAGE
            );
        }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        int rows = maze.getRows();
        int cols = maze.getCols();
        int[][] grid = maze.getGrid();

        // Background
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Draw maze cells
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                if (grid[r][c] == 1) {
                    g.setColor(Color.DARK_GRAY);
                } else {
                    g.setColor(new Color(230, 230, 230));
                }
                g.fillRect(c * cellSize, r * cellSize, cellSize, cellSize);
            }
        }

        // Draw start & goal
        g.setColor(Color.GREEN);
        g.fillRect(1 * cellSize, 1 * cellSize, cellSize, cellSize);
        g.setColor(Color.RED);
        g.fillRect((cols - 2) * cellSize, (rows - 2) * cellSize, cellSize, cellSize);

        // Draw player
        g.setColor(Color.BLUE);
        int px = player.getCol() * cellSize + cellSize / 4;
        int py = player.getRow() * cellSize + cellSize / 4;
        int pw = cellSize / 2;
        int ph = cellSize / 2;
        g.fillOval(px, py, pw, ph);

        // HUD text (moves and instructions)
        g.setColor(Color.BLACK);
        g.setFont(new Font("SansSerif", Font.PLAIN, 14));
        int hudY = rows * cellSize + 18;
        g.drawString("Moves: " + moveCount + "   R = New Maze   +/- = Resize Cells", 10, hudY);

        if (won) {
            g.drawString("You win! Press R to play again.", 10, hudY + 18);
        }
    }
}
