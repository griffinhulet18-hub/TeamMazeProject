# Maze Game Project – Final Version

## Overview

This project is a Java Swing based Maze Game created for INFO-C211.
It generates a random maze using a depth-first search backtracking algorithm and allows the player to navigate the maze using the arrow keys. The goal is to reach the red square at the bottom right corner starting from the green square at the top left.

Team Name: G2
Contributors: Griffin Hulet, Jada Thompson, Maram Algaradi, Amma Dwum

## Project Features

* Random maze generation using DFS backtracking
* Player movement with arrow keys
* Win detection when the player reaches the goal
* Move counter displayed at the bottom of the window
* Cell size can be increased or decreased with the keyboard or menu options
* Menu bar with options for creating a new maze, resizing the maze, and exiting
* Three screenshots included in the media folder
* Runnable JAR exported for final submission

## How to Import and Run the Project in Eclipse

### 1\. Create the Eclipse Project

1. Open Eclipse.
2. Select File → New → Java Project.
3. Name the project:
   MazeProject
4. Click Finish.

### 2\. Create the Package

1. Right-click the src folder.
2. Select New → Package.
3. Name the package: teammaze

### 3\. Add the Java Files

Place the following five Java files into the teammaze package:
Maze.java
MazeGenerator.java
Player.java
MazePanel.java
MazeApp.java

### 4\. Remove module-info.java (if present)

If your project contains a file named module-info.java, delete it.

### 5\. Make Sure the JRE is Correct

The project should be using JavaSE-17 or JavaSE-21.

### 6\. Run the Program

1. Open MazeApp.java.
2. Select Run → Run As → Java Application.

## Controls

Arrow Keys: move the player
R: generate a new maze
Plus or Equals key: increase cell size
Minus key: decrease cell size

## Menu Options

Game Menu:

* New Maze
* Exit

View Menu:

* Larger Cells
* Smaller Cells

## Screenshot Folder

A folder named media contains 2–3 PNG screenshots showing the maze.

## Runnable JAR Instructions

Export a runnable JAR through Eclipse:

1. Right-click MazeProject → Export
2. Java → Runnable JAR file
3. Launch configuration: MazeApp
4. Library handling: Package required libraries into generated JAR
5. Output name example: MazeProject.jar

To run the JAR from a terminal:
java -jar MazeProject.jar

## Folder Structure

MazeProject/
README.md
media/

Game Screenshots
src/
teammaze/
Maze.java
MazeGenerator.java
Player.java
MazePanel.java
MazeApp.java

