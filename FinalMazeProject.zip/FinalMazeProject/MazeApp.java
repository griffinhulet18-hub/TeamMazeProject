package teammaze;
/*
 * Team: Maze Team
 * Contributors: Maram Algaradi, Griffin Hulet, Jada Thompson, Amma Dwum
 *
 * Entry point: builds the maze, UI, and starts the game.
 */
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;

public class MazeApp {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            // Choose odd dimensions for better mazes
            int rows = 31;
            int cols = 41;

            Maze maze = new Maze(rows, cols);
            MazeGenerator gen = new MazeGenerator();
            gen.generate(maze);

            Player player = new Player(1, 1);

            int cellSize = 20;
            MazePanel panel = new MazePanel(maze, player, gen, cellSize);

            JFrame f = new JFrame("Team Maze Game");
            f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            f.setContentPane(panel);

            // Simple menu bar with resize and reset options
            JMenuBar bar = new JMenuBar();

            JMenu gameMenu = new JMenu("Game");
            JMenuItem newMazeItem = new JMenuItem("New Maze");
            newMazeItem.addActionListener(e -> panel.regenerateMaze());
            JMenuItem exitItem = new JMenuItem("Exit");
            exitItem.addActionListener(e -> System.exit(0));
            gameMenu.add(newMazeItem);
            gameMenu.add(exitItem);

            JMenu viewMenu = new JMenu("View");
            JMenuItem largerItem = new JMenuItem("Larger Cells");
            largerItem.addActionListener(e -> panel.changeCellSize(5));
            JMenuItem smallerItem = new JMenuItem("Smaller Cells");
            smallerItem.addActionListener(e -> panel.changeCellSize(-5));
            viewMenu.add(largerItem);
            viewMenu.add(smallerItem);

            bar.add(gameMenu);
            bar.add(viewMenu);
            f.setJMenuBar(bar);

            f.pack();
            f.setLocationRelativeTo(null);
            f.setResizable(true);
            f.setVisible(true);

            panel.requestFocusInWindow();
        });
    }
}
